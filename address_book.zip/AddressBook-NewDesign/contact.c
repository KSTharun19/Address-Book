#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include "file.h"
#include "populate.h"



void listContacts(AddressBook *addressBook, int sortCriteria) {
  }

void initialize(AddressBook *addressBook) {
    addressBook->contactCount = 0;
    populateAddressBook(addressBook);
    
    // Load contacts from file during initialization (After files)
    //loadContactsFromFile(addressBook);
}

void saveAndExit(AddressBook *addressBook) {
    }


void createContact(AddressBook *addressBook) {
   
}

void searchContact(AddressBook *addressBook) {
  }

void editContact(AddressBook *addressBook) {
  }

void deleteContact(AddressBook *addressBook) {
   }